package com.example.heartreachcmu

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.exp

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var ageEdit: EditText
    private lateinit var heightEdit: EditText
    private lateinit var weightEdit: EditText
    private lateinit var cholSpinner: Spinner
    private lateinit var hyperSpinner: Spinner
    private lateinit var activeSpinner: Spinner
    private lateinit var fatigueSeekBar: SeekBar
    private lateinit var nauseaSeekBar: SeekBar
    private lateinit var anxietySeekBar: SeekBar
    private lateinit var resultText: TextView
    private lateinit var checkButton: Button
    private lateinit var languageSpinner: Spinner
    //private lateinit var symptomSpinner: Spinner
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ageEdit = findViewById(R.id.ageEdit)
        heightEdit = findViewById(R.id.heightEdit)
        weightEdit = findViewById(R.id.weightEdit)
        cholSpinner = findViewById(R.id.cholSpinner)
        hyperSpinner = findViewById(R.id.hyperSpinner)
        activeSpinner = findViewById(R.id.activeSpinner)
        fatigueSeekBar = findViewById(R.id.fatigueSeekBar)
        nauseaSeekBar = findViewById(R.id.nauseaSeekBar)
        anxietySeekBar = findViewById(R.id.anxietySeekBar)
        checkButton = findViewById(R.id.checkButton)
        resultText = findViewById(R.id.resultText)
        languageSpinner = findViewById(R.id.languageSpinner)
        //symptomSpinner = findViewById(R.id.symptomSpinner)

        tts = TextToSpeech(this, this)

        // Language spinner
        val languages = listOf("English", "Hindi", "Spanish")
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages)

        // Symptom spinner (not mandatory now, since we take fatigue, nausea, anxiety scales)
        //val symptoms = listOf("None", "Anxiety", "Fatigue", "Nausea")
        //symptomSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, symptoms)

        // Setup cholesterol spinner (1=Normal, 2=Moderate, 3=High)
        val cholLevels = listOf("Normal (1)", "Moderate (2)", "High (3)")
        cholSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cholLevels)

        // Setup hypertension spinner (0=No, 1=Yes)
        val binaryOptions = listOf("No (0)", "Yes (1)")
        hyperSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, binaryOptions)
        activeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, binaryOptions)

        checkButton.setOnClickListener {
            val validationMessage = validateInputs()
            if (validationMessage.isNotEmpty()) {
                resultText.text = validationMessage
                tts.speak(validationMessage, TextToSpeech.QUEUE_FLUSH, null, null)
                return@setOnClickListener
            }

            val rawAdvice = calculateProbability()
            val lang = languageSpinner.selectedItem.toString()
            val translated = translate(rawAdvice, lang)

            resultText.text = translated
            tts.language = when (lang) {
                "Hindi" -> Locale("hi", "IN")
                "Spanish" -> Locale("es", "ES")
                else -> Locale.US
            }

            tts.speak(translated, TextToSpeech.QUEUE_FLUSH, null, null)

            //val selectedSymptom = symptomSpinner.selectedItem.toString()
            //Log.d("HeartReach", "User reported symptom: $selectedSymptom")
        }
    }

    private fun validateInputs(): String {
        // Check mandatory inputs are present and valid numbers
        if (ageEdit.text.isNullOrBlank() ||
            heightEdit.text.isNullOrBlank() ||
            weightEdit.text.isNullOrBlank() ||
            cholSpinner.selectedItem == null ||
            hyperSpinner.selectedItem == null ||
            activeSpinner.selectedItem == null
        ) {
            return "Please enter the values correctly."
        }
        val age = ageEdit.text.toString().toDoubleOrNull()
        val height = heightEdit.text.toString().toDoubleOrNull()
        val weight = weightEdit.text.toString().toDoubleOrNull()

        if (age == null || age <= 0 ||
            height == null || height <= 0 ||
            weight == null || weight <= 0
        ) {
            return "Please enter valid positive numbers for Age, Height and Weight."
        }

        // Cholesterol spinner values: Normal (1), Moderate (2), High (3)
        val cholPos = cholSpinner.selectedItemPosition
        if (cholPos !in 0..2) {
            return "Please select a valid cholesterol level."
        }

        // Hypertension and Active spinner values: No(0), Yes(1)
        val hyperPos = hyperSpinner.selectedItemPosition
        val activePos = activeSpinner.selectedItemPosition
        if (hyperPos !in 0..1 || activePos !in 0..1) {
            return "Please select valid values for hypertension and activity."
        }

        // SeekBars always valid (0 to 10 scale)
        return ""
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    private fun calculateProbability(): String {
        val age = ageEdit.text.toString().toDouble()
        val heightCm = heightEdit.text.toString().toDouble()
        val weightKg = weightEdit.text.toString().toDouble()

        // BMI calculation: weight (kg) / (height (m))^2
        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)

        val chol = cholSpinner.selectedItemPosition + 1 // 1,2,3
        val hypertension = hyperSpinner.selectedItemPosition.toDouble() // 0 or 1
        val active = activeSpinner.selectedItemPosition.toDouble() // 0 or 1

        // Symptom severity scales 0-10 from seekbars
        val fatigue = fatigueSeekBar.progress.toDouble()
        val nausea = nauseaSeekBar.progress.toDouble()
        val anxiety = anxietySeekBar.progress.toDouble()

        Log.d("HeartReach", "Inputs - Age: $age, Height: $heightCm, Weight: $weightKg, BMI: $bmi, Chol: $chol, Hypertension: $hypertension, Active: $active, Fatigue: $fatigue, Nausea: $nausea, Anxiety: $anxiety")

        var linear = -2.35453395
        linear += 1.686107 * hypertension
        linear += 0.560555 * chol
        linear += 0.033108 * bmi
        linear += 0.002778 * age
        linear += -0.202224 * active

        // Add symptom scores weighted to model
        linear += 0.05 * fatigue
        linear += 0.04 * nausea
        linear += 0.06 * anxiety

        val probability = 1 / (1 + exp(-linear))

        Log.d("HeartReach", "Computed probability: $probability")

        return when {
            probability >= 0.75 -> "High risk detected. Please seek urgent medical care immediately. Risk Score: %.2f".format(probability)
            probability >= 0.5 -> "Moderate risk detected. We recommend scheduling a doctor visit soon. Risk Score: %.2f".format(probability)
            else -> "Low risk detected. Maintain healthy habits and monitor your health. Risk Score: %.2f".format(probability)
        }
    }

    private fun translate(text: String, lang: String): String {
        return when (lang) {
            "Hindi" -> when {
                text.contains("High risk") -> "उच्च जोखिम का पता चला। कृपया तुरंत चिकित्सा सहायता लें। जोखिम स्कोर: %.2f".format(extractScore(text))
                text.contains("Moderate risk") -> "मध्यम जोखिम का पता चला। कृपया डॉक्टर से परामर्श लें। जोखिम स्कोर: %.2f".format(extractScore(text))
                text.contains("Low risk") -> "कम जोखिम का पता चला। स्वस्थ आदतें बनाए रखें और अपने स्वास्थ्य की निगरानी करें। जोखिम स्कोर: %.2f".format(extractScore(text))
                else -> text
            }
            "Spanish" -> when {
                text.contains("High risk") -> "Alto riesgo detectado. Por favor busque atención médica inmediata. Puntaje de riesgo: %.2f".format(extractScore(text))
                text.contains("Moderate risk") -> "Riesgo moderado detectado. Recomendamos programar una visita al médico pronto. Puntaje de riesgo: %.2f".format(extractScore(text))
                text.contains("Low risk") -> "Bajo riesgo detectado. Mantenga hábitos saludables y monitoree su salud. Puntaje de riesgo: %.2f".format(extractScore(text))
                else -> text
            }
            else -> text // English
        }
    }


    private fun extractScore(text: String): Double {
        val regex = Regex("([0-9]+\\.[0-9]+)")
        val match = regex.find(text)
        return match?.value?.toDoubleOrNull() ?: 0.0
    }
}
